package com.example.lastapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Ed_doctor extends AppCompatActivity {

    private TextView textView1;
    private TextView textView2;
    private TextView textView3;
    private TextView textView4;
    private TextView textView5;
    private TextView textView6;
    Button button;

    // Declare pid at the class level
    private String pid;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ed_doctor);

//        textView1 = findViewById(R.id.tx1);
        textView2 = findViewById(R.id.tx2);
        textView3 = findViewById(R.id.tx3);
        textView4 = findViewById(R.id.tx4);
        textView5 = findViewById(R.id.tx5);
        textView6 = findViewById(R.id.tx6);
        button = findViewById(R.id.button);

        // Get pid from intent
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            pid = extras.getString("id");
        }

        // Make an HTTP request to your PHP script
        fetchStringFromPHP();

        // Set OnClickListener to the button
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call sendJsonData() when the button is clicked
                sendJsonData();
            }
        });
    }

    private void fetchStringFromPHP() {
        String url = "http://192.168.238.33/backend/printDocInfo.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    if (jsonObject.has("did")) {
//                        final String status = jsonObject.getString("did");
//                        runOnUiThread(new Runnable() {
//                            @Override
//                            public void run() {
//                                textView1.setText(status);
//
//                                // Print doctor ID for debugging
//                                Log.d("Doctor ID", "Doctor ID: " + status);
//                            }
//                        });

                        // Update other TextViews similarly...
                        if (jsonObject.has("name")) {
                            final String tx2 = jsonObject.getString("name");
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    textView2.setText(tx2);
                                }
                            });
                        }
                        if (jsonObject.has("phno")) {
                            final String tx3 = jsonObject.getString("phno");
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    textView3.setText(tx3);
                                }
                            });
                        }
                        if (jsonObject.has("pass")) {
                            final String tx4 = jsonObject.getString("pass");
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    textView4.setText(tx4);
                                }
                            });
                        }
                        if (jsonObject.has("gender")) {
                            final String tx5 = jsonObject.getString("gender");
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    textView5.setText(tx5);
                                }
                            });
                        }
                        if (jsonObject.has("speciality")) {
                            final String tx6 = jsonObject.getString("speciality");
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    textView6.setText(tx6);
                                }
                            });
                        }
                        // Repeat for other text views...
                    } else {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                textView1.setText("Doctor ID not found in JSON response");
                            }
                        });
                    }
                } catch (JSONException e) {
                    final String errorMessage = "Error: " + e.getMessage();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            textView1.setText(errorMessage);
                        }
                    });
                }
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                final String errorMessage = "Error: " + error.getMessage();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textView1.setText(errorMessage);
                    }
                });
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> data = new HashMap<>();
                Log.d("giving", pid);
                data.put("id", pid);
                return data;
            }
        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void sendJsonData() {
        String URL = "http://192.168.238.33/backend/updDoc.php";
        // Get the data from EditText fields
//        String id = textView1.getText().toString();
        String name = textView2.getText().toString();
        String phno = textView3.getText().toString();
        String password = textView4.getText().toString();
        String gender = textView5.getText().toString();
        String speciality = textView6.getText().toString();
        // Create a JSON object with the data
        JSONObject jsonData = new JSONObject();
        try {

            jsonData.put("name", name);
            Log.d("avac", name);
            jsonData.put("phno", phno);
            jsonData.put("did", pid);
            jsonData.put("pass", password);
            jsonData.put("gender", gender);
            jsonData.put("spec", speciality);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Intent intent1 = getIntent();
        String value = intent1.getStringExtra("id");

        // Send the JSON data to the PHP script using Volley
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, URL, jsonData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        // Check if the JSON response contains a "status" key
                        if (response.has("status")) {
                            String status = null;
                            try {
                                status = response.getString("status");
                            } catch (JSONException e) {
                                throw new RuntimeException(e);
                            }
                            if (status.equals("success")) {
                                // Data was updated successfully
                                try {
                                    String message = response.getString("message");
                                    Toast.makeText(Ed_doctor.this, message, Toast.LENGTH_SHORT).show();

                                    Intent intent = new Intent(Ed_doctor.this, admindashboard.class);
                                    intent.putExtra("item", value);
                                    startActivity(intent);
                                } catch (JSONException e) {
                                    throw new RuntimeException(e);
                                }

                            } else {
                                // Data update was not successful
                                try {
                                    String message = response.getString("message");
                                    Toast.makeText(Ed_doctor.this, message, Toast.LENGTH_SHORT).show();
                                } catch (JSONException e) {
                                    throw new RuntimeException(e);
                                }

                            }
                        } else {

                        }
                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle errors (if needed)
                    }
                }
        );
        requestQueue.add(jsonObjectRequest);
    }
}
